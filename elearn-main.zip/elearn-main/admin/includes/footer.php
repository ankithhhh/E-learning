<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; Designed by Chirag & Ankith
                </div>

            </div>
        </div>
    </footer>

    <style> .col-md-12{text-align: center;} </style>
