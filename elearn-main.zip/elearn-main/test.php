<?php
echo $_POST['regno'];
echo $_POST['password'];


?>